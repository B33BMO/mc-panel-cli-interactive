See mccli.py usage in the chat.
